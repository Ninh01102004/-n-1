<?php
include 'config.php';

// Lấy từ khóa tìm kiếm nếu có
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Truy vấn SQL có điều kiện tìm kiếm theo TenHang
if ($search != '') {
    $sql = "SELECT * FROM thucpham WHERE TenHang LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM thucpham";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Thực Phẩm</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .search-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-form input[type="text"] {
            padding: 8px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-form input[type="submit"] {
            padding: 8px 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 5px;
            cursor: pointer;
        }

        .search-form input[type="submit"]:hover {
            background: #218838;
        }

        .product-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .product-card {
            background: white;
            width: 220px;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: 0.3s;
        }

        .product-card:hover {
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        }

        .product-card img {
            max-width: 100%;
            height: 140px;
            object-fit: cover;
            margin-bottom: 10px;
        }

        .product-card h4 {
            margin: 5px 0;
            font-size: 18px;
            color: #333;
        }

        .product-card p {
            margin: 5px 0;
            font-size: 14px;
            color: #666;
        }

        .btn-detail {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 12px;
            background: #007bff;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-detail:hover {
            background: #0056b3;
        }

        .btn-back {
            display: inline-block;
            background: #6c757d;
            color: white;
            padding: 8px 14px;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .btn-back:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <a href="index.php" class="btn-back">⬅️ Quay lại Trang chủ</a>

    <h2>📦 Danh Sách Thực Phẩm</h2>

    <div class="search-form">
        <form method="get" action="">
            <input type="text" name="search" placeholder="Tìm theo tên thực phẩm..." value="<?php echo htmlspecialchars($search); ?>">
            <input type="submit" value="Tìm kiếm">
        </form>
    </div>

    <div class="product-container">
    <?php 
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <div class="product-card">
            <img src="images/<?php echo $row['HinhAnh']; ?>" alt="<?php echo $row['TenHang']; ?>">
            <h4><?php echo $row['TenHang']; ?></h4>
            <p>Giá: <?php echo number_format($row['DonGia']); ?> VND</p>
            <p>ĐVT: <?php echo $row['DVT']; ?></p>
            <p>HSD: <?php echo $row['HSD']; ?></p>
            <a href="chitiet_thucpham.php?MaHang=<?php echo $row['MaHang']; ?>" class="btn-detail">Chi tiết</a>
        </div>
    <?php
        }
    } else {
        echo "<p style='text-align:center;'>Không tìm thấy thực phẩm nào!</p>";
    }
    ?>
    </div>

</body>
</html>
