<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$database = "quanly_thucpham"; 

// Kết nối MySQL
$conn = mysqli_connect($servername, $username, $password, $database);

// Kiểm tra kết nối
if (!$conn) {
    die("❌ Kết nối database thất bại: " . mysqli_connect_error());
} else {
    echo "";
}
// Đặt UTF-8 để tránh lỗi font tiếng Việt
mysqli_set_charset($conn, "utf8");
$conn->set_charset("utf8");
?>
