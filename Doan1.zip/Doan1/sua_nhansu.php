<?php
include 'config.php';

$MaNV = $_GET['id'];
$sql = "SELECT * FROM nhanvien WHERE MaNV = '$MaNV'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ten = $_POST['TenNV'];
    $chucvu = $_POST['ChucVu'];
    $sdt = $_POST['SDT'];
    $nsinh = $_POST['NSinh'];
    $dchi = $_POST['DChi'];
    $luong = $_POST['LUONG'];

    $sql = "UPDATE nhanvien SET
            TenNV='$ten',
            ChucVu='$chucvu',
            SDT='$sdt',
            NSinh='$nsinh',
            DChi='$dchi',
            LUONG='$luong'
        WHERE MaNV='$MaNV'";

    if ($conn->query($sql) === TRUE) {
        header("Location: nhanvien.php");
    } else {
        echo "❌ Lỗi cập nhật: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Nhà Cung Cấp</title>
    <style>
        /* Định dạng chung */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        /* Tiêu đề */
        h2 {
            color: #007bff;
        }

        /* Form nhập liệu */
        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
            text-align: left;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* Nút bấm */
        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }

        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    
<h2>✏️ Sửa Nhân Viên</h2>
    <form method="post">
        Mã nhân viên: <input type="text" name="MaNV" value="<?= $row['MaNV'] ?>" readonly>
        Tên nhân viên: <input type="text" name="TenNV" value="<?= $row['TenNV'] ?>"><br><br>
        Chức vụ: <input type="text" name="ChucVu" value="<?= $row['ChucVu'] ?>"><br><br>
        SĐT: <input type="text" name="SDT" value="<?= $row['SDT'] ?>"><br><br>
        Ngày sinh: <input type="date" name="NSinh" value="<?= $row['NSinh'] ?>"><br><br>
        Địa chỉ: <input type="text" name="DChi" value="<?= $row['DChi'] ?>"><br><br>
        Lương: <input type="number" name="LUONG" value="<?= $row['LUONG'] ?>"><br><br>
        <button type="submit">💾 Cập nhật</button>
    </form>
    <br>
    <a href="nhanvien.php">⬅️ Quay lại danh sách</a>
</body>
</html>