<?php
include 'config.php';

if (isset($_GET['id'])) {
    $ma = $_GET['id'];
    $sql = "DELETE FROM nhanvien WHERE MaNV = '$ma'";

    if ($conn->query($sql) === TRUE) {
        header("Location: nhanvien.php");
    } else {
        echo "❌ Lỗi xóa: " . $conn->error;
    }
} else {
    echo "Không tìm thấy mã nhân viên!";
}
?>
