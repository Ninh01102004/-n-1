<?php
include 'config.php';

if (isset($_GET['id'])) {
    $MaKH = $_GET['id'];
    $sql = "DELETE FROM khachhang WHERE MaKH = '$MaKH'";

    if ($conn->query($sql) === TRUE) {
        header("Location: khachhang.php");
    } else {
        echo "❌ Lỗi xóa: " . $conn->error;
    }
} else {
    echo "Không tìm thấy mã nhà cung cấp!";
}
?>
