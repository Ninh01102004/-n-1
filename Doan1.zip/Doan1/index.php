<?php include 'menu.php'; ?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Trang Chủ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Ảnh nền full màn hình -->
    <img class="bg-image" src="thucpham.png" alt="Thực Phẩm Sạch">

    <!-- Phần chữ hiển thị phía dưới -->
    <div class="container">
        <h2>Chào mừng bạn đến với hệ thống Quản Lý Cửa Hàng</h2>
        <p>Quản lý dễ dàng, nhanh chóng và hiệu quả</p>
    </div>
</body>
</html>
