<?php
include 'config.php';

if (isset($_GET['id'])) {
    $ma = $_GET['id'];
    $sql = "DELETE FROM nhacungcap WHERE MaNCC = '$ma'";

    if ($conn->query($sql) === TRUE) {
        header("Location: nhacungcap.php");
    } else {
        echo "❌ Lỗi xóa: " . $conn->error;
    }
} else {
    echo "Không tìm thấy mã nhà cung cấp!";
}
?>

