<?php
include 'config.php'; // Kết nối cơ sở dữ liệu

$search = isset($_GET['search']) ? $_GET['search'] : '';
$search = $conn->real_escape_string($search); // Ngăn chặn SQL injection

// Truy vấn dữ liệu nhân viên (tìm kiếm nếu có từ khóa)
if ($search != '') {
    $sql = "SELECT * FROM nhanvien 
            WHERE CONCAT(MaNV, TenNV, ChucVu, SDT, NSinh, DChi) LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM nhanvien";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Nhân Viên</title>
    <style>
         * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
    }
    /* Tổng thể */
    body {
    background-color: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    }
    form {
            text-align: center;
            margin-bottom: 20px;
    }

    form input {
            padding: 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
    }

    form button {
            padding: 10px 15px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

    form button:hover {
            background-color: #138496;
        }

       

/* Container chính */
.container {
    width: 90%;
    max-width: 1200px;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    text-align: center;
}

/* Tiêu đề */
h2 {
    color: #333;
    margin-bottom: 20px;
}

/* Nút thêm mới */
.btn-add {
    display: inline-block;
    background: #28a745;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    margin-bottom: 15px;
    font-weight: bold;
}

.btn-add:hover {
    background: #218838;
}

/* Bảng */
table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}

th {
    background: #17a2b8;
    color: white;
    font-size: 16px;
}

/* Nút sửa và xóa */
.btn-edit, .btn-delete {
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 5px;
    font-weight: bold;
    display: inline-block;
}

.btn-edit {
    background: #ffc107;
    color: #000;
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.btn-edit:hover {
    background: #e0a800;
}

.btn-delete:hover {
    background: #c82333;
}
.btn-back{
    position: absolute;
    top: 20px;
    left: 20px;
    background: #6c757d;
    color: white;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    z-index: 999;
}

.btn-back:hover {
    background: #5a6268;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>📋 Danh sách Nhân Viên</h2>

        <!-- Form tìm kiếm -->
        <form method="get" action="">
            <input type="text" name="search" placeholder="Nhập từ khóa tìm kiếm..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">🔍 Tìm kiếm</button>
        </form>

        <a href="them_nhansu.php" class="btn-add">+ Thêm Nhân Viên</a>

        <table>
            <tr>
                <th>Mã NV</th>
                <th>Tên Nhân Viên</th>
                <th>Chức Vụ</th>
                <th>SĐT</th>
                <th>Ngày Sinh</th>
                <th>Địa Chỉ</th>
                <th>Lương</th>
                <th>Tùy chọn</th>
            </tr>

            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['MaNV'] ?></td>
                        <td><?= $row['TenNV'] ?></td>
                        <td><?= $row['ChucVu'] ?></td>
                        <td><?= $row['SDT'] ?></td>
                        <td><?= $row['NSinh'] ?></td>
                        <td><?= $row['DChi'] ?></td>
                        <td><?= number_format($row['LUONG'], 0, ',', '.') ?>đ</td>
                        <td>
                            <a href="sua_nhansu.php?id=<?= $row['MaNV'] ?>" class="btn-edit">✏️ Sửa</a>
                            <a href="xoa_nhansu.php?id=<?= $row['MaNV'] ?>" class="btn-delete" onclick="return confirm('Bạn có chắc muốn xóa?')">🗑️ Xóa</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="8">Không tìm thấy kết quả phù hợp.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
