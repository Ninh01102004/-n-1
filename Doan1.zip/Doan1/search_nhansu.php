<?php
include 'config.php'; // Kết nối CSDL

$search = isset($_GET['search']) ? $_GET['search'] : ''; // Lấy giá trị tìm kiếm

// Cập nhật câu truy vấn để lọc theo tên nhân viên hoặc các thông tin khác
$sql = "SELECT * FROM nhanvien WHERE TenNV LIKE '%$search%' OR ChucVu LIKE '%$search%' OR SDT LIKE '%$search%' OR DChi LIKE '%$search%'";
$result = $conn->query($sql);

if (!$result) {
    die("❌ Lỗi truy vấn: " . $conn->error);
}

// Trả về kết quả dưới dạng HTML
$output = '';
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $output .= '
            <tr>
                <td>' . $row['MaNV'] . '</td>
                <td>' . $row['TenNV'] . '</td>
                <td>' . $row['ChucVu'] . '</td>
                <td>' . $row['SDT'] . '</td>
                <td>' . $row['NSinh'] . '</td>
                <td>' . $row['DChi'] . '</td>
                <td>' . number_format($row['LUONG'], 0, ',', '.') . 'đ</td>
                <td>
                    <a href="sua_nhansu.php?id=' . $row['MaNV'] . '" class="btn-edit">✏️ Sửa</a>
                    <a href="xoa_nhansu.php?id=' . $row['MaNV'] . '" class="btn-delete" onclick="return confirm(\'Bạn có chắc muốn xóa?\')">🗑️ Xóa</a>
                </td>
            </tr>
        ';
    }
} else {
    $output = '<tr><td colspan="8">Không có dữ liệu</td></tr>';
}

echo $output;
?>
