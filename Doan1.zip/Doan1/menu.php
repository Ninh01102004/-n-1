<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Cửa Hàng</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <img src="logo.png" alt="Logo Cửa Hàng">
        <h1>Hệ Thống Quản Lý Cửa Hàng</h1>
    </div>
    <div class="menu">
        <a href="index.php">🏠 Trang Chủ</a>
       <a href="nhacungcap.php">📋QL Nhà Cung Cấp</a>
        <a href="khachhang.php">👥 QL Khách Hàng</a>
        <a href="nhanvien.php">👔 QL Nhân Viên</a>
        <a href="thucpham.php">🍎 QL Thực Phẩm</a>
        <a href="kho.php">📦 QL Kho</a>
        <a href="tai_chinh.php">💰 QL Tài Chính</a>
        <a href="bao_cao.php">📊 Báo Cáo</a>
    </div>
</body>
</html>
