<?php
include 'config.php'; // Kết nối database

$sql = "SELECT * FROM nhacungcap";
$result = $conn->query($sql);

if (!$result) {
    die("❌ Lỗi truy vấn: " . $conn->error);
} else {
    echo "✅ Truy vấn thành công!<br>";
    echo "Số dòng trả về: " . $result->num_rows . "<br>";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Nhà Cung Cấp</title>
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        /* Reset CSS */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

/* Tổng thể */
body {
    background-color: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* Container chính */
.container {
    width: 90%;
    max-width: 1200px;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    text-align: center;
}

/* Tiêu đề */
h2 {
    color: #333;
    margin-bottom: 20px;
}

/* Nút thêm mới */
.btn-add {
    display: inline-block;
    background: #28a745;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    margin-bottom: 15px;
    font-weight: bold;
}

.btn-add:hover {
    background: #218838;
}

/* Bảng */
table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}

th {
    background: #17a2b8;
    color: white;
    font-size: 16px;
}

/* Nút sửa và xóa */
.btn-edit, .btn-delete {
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 5px;
    font-weight: bold;
    display: inline-block;
}

.btn-edit {
    background: #ffc107;
    color: #000;
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.btn-edit:hover {
    background: #e0a800;
}

.btn-delete:hover {
    background: #c82333;
}
.btn-back {
    position: absolute;
    top: 20px;
    left: 20px;
    background: #6c757d;
    color: white;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    z-index: 1000;
}



    </style>
</head>
<body>
    <a href="index.php" class="btn-back">⬅️ Quay lại Trang chủ</a>
    <h2>📋 Danh sách Nhà Cung Cấp</h2>
<div class="container">
    
    <a href="them_ncc.php" class="btn-add">+ Thêm Nhà Cung Cấp</a>
       <table>
    <tr>
        <th>Mã nhà cung cấp</th>
        <th>Tên nhà cung cấp</th>
        <th>Địa chỉ nhà cung cấp</th>
        <th>Loại hàng</th>
        <th>Tùy chọn</th>
    </tr>
    
    <?php  
    if ($result->num_rows > 0) { // Kiểm tra có dữ liệu không
        while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['MaNCC']; ?></td>
                <td><?php echo $row['TenNCC']; ?></td>
                <td><?php echo $row['DChiNCC']; ?></td>
                <td><?php echo $row['LoaiHang']; ?></td>
                <td>
                    <a href="sua_ncc.php?id=<?php echo $row['MaNCC']; ?>" class="btn-edit">✏️ Sửa</a>
             <a href="xoa_ncc.php?id=<?php echo urlencode(trim($row['MaNCC'])); ?>" class="btn-delete" onclick="return confirm('Bạn có chắc muốn xóa?')">🗑️ Xóa</a>

                </td>
            </tr>
        <?php } 
    } else { ?>
        <tr>
            <td colspan="7" style="text-align:center;">Không có dữ liệu</td>
        </tr>
    <?php } ?>
</table>
</div>


</body>
</html>
