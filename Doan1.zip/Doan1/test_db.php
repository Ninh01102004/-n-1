<?php
include 'config.php';
if ($conn) {
    echo "✅ Kết nối MySQL thành công!";
} else {
    echo "❌ Kết nối thất bại: " . mysqli_connect_error();
}
?>
