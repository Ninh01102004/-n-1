<?php
include 'config.php'; // Kết nối database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ form
    $MaKH = $_POST['MaKH'];
    $TenKH = $_POST['TenKH'];
    $DCHI = $_POST['DCHI'];
    $SDT = $_POST['SDT'];

    // Truy vấn SQL để thêm khách hàng vào database
    $sql = "INSERT INTO khachhang (MaKH, TenKH, DCHI, SDT) 
            VALUES ('$MaKH', '$TenKH', '$DCHI', '$SDT')";
    
    if (mysqli_query($conn, $sql)) {
        echo "✅ Thêm khách hàng thành công!";
        header("Location:khachhang.php"); // Điều hướng trở lại danh sách khách hàng
    } else {
        echo "❌ Lỗi: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Khách Hàng</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
        /* Định dạng chung */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        /* Tiêu đề */
        h2 {
            color: #007bff;
        }

        /* Form nhập liệu */
        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
            text-align: left;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* Nút bấm */
        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }

        button:hover {
            background: #218838;
        }
    </style>
<body>
    <h2>Thêm Khách Hàng</h2>
    <form method="POST">
        <label>Mã khách hàng</label> <input type="text" name="MaKH" required><br><br>
        <label>Tên khách hàng</label> <input type="text" name="TenKH" required><br><br>
        <label>Địa chỉ</label> <input type="text" name="DCHI" required><br><br>
        <label>SĐT</label> <input type="text" name="SDT" required><br><br>
        <button type="submit">✅ Thêm</button>
    </form>
</body>
</html>
