<?php
include("config.php");

if (isset($_GET['MaHang'])) {
    $MaHang = $_GET['MaHang'];
    $sql = "SELECT tp.*, ncc.TenNCC FROM thucpham tp 
            JOIN nhacungcap ncc ON tp.MaNCC = ncc.MaNCC
            WHERE tp.MaHang = '$MaHang'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
} else {
    echo "Không có sản phẩm được chọn.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chi tiết sản phẩm</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
        }
        .product-detail {
            width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .product-detail img {
            max-width: 100%;
            height: auto;
        }
        .product-detail h2 {
            margin-top: 0;
            color: #2d6a4f;
        }
        .back-btn {
            margin-top: 20px;
            display: inline-block;
            padding: 8px 12px;
            background: #007bff;
            color: white;
            border-radius: 4px;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="product-detail">
    <h2><?php echo $row['TenHang']; ?></h2>
    <img src="images/<?php echo $row['HinhAnh']; ?>" alt="<?php echo $row['TenHang']; ?>">
    <p><strong>Mã hàng:</strong> <?php echo $row['MaHang']; ?></p>
    <p><strong>Đơn giá:</strong> <?php echo number_format($row['DonGia']); ?> VND</p>
    <p><strong>Đơn vị tính:</strong> <?php echo $row['DVT']; ?></p>
    <p><strong>Nhà cung cấp:</strong> <?php echo $row['TenNCC']; ?></p>
    <p><strong>Hạn sử dụng:</strong> <?php echo $row['HSD']; ?></p>
    <p><strong>Số lượng bán:</strong> <?php echo $row['SoLuongBan']; ?> lượt</p>
    <a href="thucpham.php" class="back-btn">Quay lại</a>
</div>
</body>
</html>
