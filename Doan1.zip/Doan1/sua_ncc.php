<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $MaNCC = $_POST['MaNCC'];
    $TenNCC = $_POST['TenNCC'];
    $DChiNCC = $_POST['DChiNCC'];
    $LoaiHang = $_POST['LoaiHang'];

    $sql = "UPDATE nhacungcap 
            SET TenNCC = '$TenNCC', DChiNCC = '$DChiNCC', LoaiHang = '$LoaiHang' 
            WHERE MaNCC = '$MaNCC'";

    if (mysqli_query($conn, $sql)) {
        echo "✅ Cập nhật thành công!";
        header("Location: nhacungcap.php");
        exit();
    } else {
        echo "❌ Lỗi: " . mysqli_error($conn);
    }
}

// Lấy thông tin nhà cung cấp để hiển thị trong form sửa
if (isset($_GET['MaNCC'])) {
    $MaNCC = $_GET['MaNCC'];
    $sql = "SELECT * FROM nhacungcap WHERE MaNCC = '$MaNCC'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Nhà Cung Cấp</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        h2 {
            color: #007bff;
        }

        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
            text-align: left;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }

        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <h2>Sửa Nhà Cung Cấp</h2>
    <form method="POST">
        <label>Mã Nhà Cung Cấp:</label>
        <input type="text" name="MaNCC" value="<?= isset($row['MaNCC']) ? $row['MaNCC'] : '' ?>">

        <label>Tên Nhà Cung Cấp:</label>
        <input type="text" name="TenNCC" value="<?= isset($row['TenNCC']) ? $row['TenNCC'] : '' ?>" required>

        <label>Địa Chỉ:</label>
        <input type="text" name="DChiNCC" value="<?= isset($row['DChiNCC']) ? $row['DChiNCC'] : '' ?>" required>

        <label>Loại Hàng:</label>
        <input type="text" name="LoaiHang" value="<?= isset($row['LoaiHang']) ? $row['LoaiHang'] : '' ?>" required>

        <button type="submit">✅ Lưu</button>
    </form>
</body>
</html>
