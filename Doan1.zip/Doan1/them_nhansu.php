<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $MaNV = $_POST['MaNV'];
    $TenNV = $_POST['TenNV'];
    $ChucVu = $_POST['ChucVu'];
    $SDT = $_POST['SDT'];
    $NSinh = $_POST['NSinh'];
    $DChi= $_POST['DChi'];
    $LUONG = $_POST['LUONG'];
     $sql = "INSERT INTO nhanvien (MaNV, TenNV, ChucVu, SDT, NSinh, DChi, LUONG)
            VALUES ('$MaNV', '$TenNV', '$ChucVu', '$SDT', '$NSinh', '$DChi', '$LUONG')";
    
    if (mysqli_query($conn, $sql)) {
        echo "";
        header("Location: nhanvien.php");
    } else {
        echo "❌ Lỗi: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Nhà Nhân Viên</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
        /* Định dạng chung */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        /* Tiêu đề */
        h2 {
            color: #007bff;
        }

        /* Form nhập liệu */
        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
            text-align: left;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* Nút bấm */
        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }

        button:hover {
            background: #218838;
        }
    </style>
<body>
    <h2>Thêm Nhân Viên</h2>
     <form method="post">
        Mã NV: <input type="text" name="MaNV" required><br><br>
        Tên NV: <input type="text" name="TenNV" required><br><br>
        Chức vụ: <input type="text" name="ChucVu"><br><br>
        SĐT: <input type="text" name="SDT"><br><br>
        Ngày sinh: <input type="date" name="NSinh"><br><br>
        Địa chỉ: <input type="text" name="DChi"><br><br>
        Lương: <input type="number" name="LUONG"><br><br>
        <button type="submit">💾 Lưu</button>
    </form>
    <br>
    <a href="nhanvien.php">⬅️ Quay lại danh sách</a>
</body>
</html>
